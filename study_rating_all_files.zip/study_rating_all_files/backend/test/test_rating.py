# completed on June 22

import pytest
from httpx import AsyncClient
from main import app

# This test checks if the rating endpoint works
@pytest.mark.asyncio
async def test_submit_rating():
    async with AsyncClient(app=app, base_url="http://test") as client:
        response = await client.post("/rate", json={
            "session_id": 1,
            "reviewer_id": 2,
            "partner_id": 3,
            "rating": 5,
            "feedback": "Really chill partner!"
        })
        assert response.status_code == 200
        assert response.json() == {"message": "Rating submitted"}
