# completed on June 22

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, conint
from database import database

router = APIRouter()

# This is the data we expect from the form
class RatingInput(BaseModel):
    session_id: int
    reviewer_id: int
    partner_id: int
    rating: conint(ge=1, le=5)
    feedback: str | None = None

# This is the API students use to submit feedback
@router.post("/rate")
async def rate_partner(data: RatingInput):
    # Make sure the session actually happened
    session_check = await database.fetch_one(
        """
        SELECT id FROM study_sessions
        WHERE id = :session_id AND status = 'completed'
        """,
        {"session_id": data.session_id}
    )
    if not session_check:
        raise HTTPException(status_code=400, detail="Session not complete")

    # Don’t let someone rate the same session twice
    existing = await database.fetch_one(
        """
        SELECT id FROM ratings
        WHERE session_id = :session_id AND reviewer_id = :reviewer_id
        """,
        {"session_id": data.session_id, "reviewer_id": data.reviewer_id}
    )
    if existing:
        raise HTTPException(status_code=400, detail="Already rated this session")

    # Save the rating to the database
    await database.execute(
        """
        INSERT INTO ratings (session_id, reviewer_id, partner_id, rating, feedback)
        VALUES (:session_id, :reviewer_id, :partner_id, :rating, :feedback)
        """,
        data.dict()
    )

    return {"message": "Rating submitted"}
